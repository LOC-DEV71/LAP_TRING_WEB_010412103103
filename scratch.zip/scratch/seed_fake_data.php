<?php
require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../core/helpers.php';
loadEnv(__DIR__ . '/../.env');
require_once __DIR__ . '/../config/database.php'; // Kết nối PDO qua biến $conn

try {
    echo "Bắt đầu nạp dữ liệu mẫu để kiểm thử...\n";

    // Tạo bảng Danh mục sản phẩm (Bổ sung cột description và thumbnail)
    $conn->exec("
        CREATE TABLE IF NOT EXISTS product_categories (
            _id VARCHAR(50) PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            slug VARCHAR(255) NOT NULL,
            description VARCHAR(255),
            thumbnail VARCHAR(255),
            position INT DEFAULT 0,
            status VARCHAR(50) DEFAULT 'active',
            deleted TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");

    // Tạo bảng Menu thanh điều hướng (Navbar)
    $conn->exec("
        CREATE TABLE IF NOT EXISTS navbars (
            _id VARCHAR(50) PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            link VARCHAR(255) NOT NULL,
            position INT DEFAULT 0,
            status VARCHAR(50) DEFAULT 'active',
            deleted TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");

    // Tạo bảng Cấu hình hệ thống (Settings)
    $conn->exec("
        CREATE TABLE IF NOT EXISTS settings (
            `key` VARCHAR(50) PRIMARY KEY,
            `value` TEXT,
            `description` VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");

    // Tắt kiểm tra khóa ngoại để dọn dẹp bảng
    $conn->exec("SET FOREIGN_KEY_CHECKS=0;");
    $conn->exec("TRUNCATE TABLE product_variants;");
    $conn->exec("TRUNCATE TABLE product_images;");
    $conn->exec("TRUNCATE TABLE products;");
    $conn->exec("TRUNCATE TABLE product_categories;");
    $conn->exec("TRUNCATE TABLE orders;");
    $conn->exec("TRUNCATE TABLE users;");
    $conn->exec("TRUNCATE TABLE navbars;");
    $conn->exec("TRUNCATE TABLE settings;");
    
    // Dọn dẹp thêm các bảng liên kết để tránh lỗi khóa ngoại rác
    $extraTables = ['likes', 'cart_items', 'carts', 'order_items'];
    foreach ($extraTables as $tbl) {
        try {
            $conn->exec("TRUNCATE TABLE `$tbl`;");
        } catch (\Exception $e) {
            // Bỏ qua nếu bảng không tồn tại trong DB hiện tại
        }
    }
    
    $conn->exec("SET FOREIGN_KEY_CHECKS=1;");

    // 0. Thêm cấu hình trang chủ mặc định (Default Settings)
    $defaultSettings = [
        ['home_hero_subtitle', 'BỘ SƯU TẬP MÙA HÈ 2026', 'Subtitle của Hero Section'],
        ['home_hero_title', "NEW SEASON\nNEW STYLE", 'Title của Hero Section'],
        ['home_hero_sale', 'Giảm đến 50% cho tất cả sản phẩm', 'Thông tin khuyến mãi Hero Section'],
        ['home_hero_button_text', 'MUA NGAY', 'Chữ trên nút Hero Section'],
        ['home_hero_button_link', 'products', 'Đường dẫn nút Hero Section'],
        ['home_hero_image', 'assets/images/banner1.jpg', 'Ảnh nền của Hero Section'],
        ['home_sale_banner_title', 'SALE UP TO 70%', 'Tiêu đề Banner khuyến mãi lớn'],
        ['home_sale_banner_button_text', 'MUA NGAY', 'Chữ trên nút Banner khuyến mãi lớn'],
        ['home_sale_banner_button_link', 'products', 'Đường dẫn nút Banner khuyến mãi lớn']
    ];
    
    $stmtSetting = $conn->prepare("INSERT INTO settings (`key`, `value`, `description`) VALUES (:key, :value, :description)");
    foreach ($defaultSettings as $setting) {
        $stmtSetting->execute([
            ':key' => $setting[0],
            ':value' => $setting[1],
            ':description' => $setting[2]
        ]);
    }

    // 1. Thêm danh mục sản phẩm (Product Categories - Đầy đủ ảnh và mô tả)
    $categories = [
        ['_id' => 'cat_nam', 'title' => 'Thời trang Nam', 'slug' => 'nam', 'description' => 'Phóng khoáng & Lịch lãm', 'thumbnail' => 'https://images.unsplash.com/photo-1488161628813-04466f872be2?w=600', 'position' => 1, 'status' => 'active'],
        ['_id' => 'cat_nu', 'title' => 'Thời trang Nữ', 'slug' => 'nu', 'description' => 'Duyên dáng & Kiêu kỳ', 'thumbnail' => 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=600', 'position' => 2, 'status' => 'active'],
        ['_id' => 'cat_phukien', 'title' => 'Phụ kiện', 'slug' => 'phu-kien', 'description' => 'Hoàn thiện phong cách', 'thumbnail' => 'https://images.unsplash.com/photo-1523293182086-7651a899d37f?w=600', 'position' => 3, 'status' => 'active'],
        ['_id' => 'cat_collection', 'title' => 'Bộ sưu tập', 'slug' => 'bo-suu-tap', 'description' => 'SUMMER', 'thumbnail' => 'https://images.unsplash.com/photo-1509319117193-57bab727e09d?w=800', 'position' => 4, 'status' => 'active'],
        ['_id' => 'cat_sport', 'title' => 'NĂNG ĐỘNG', 'slug' => 'do-the-thao', 'description' => 'Trẻ trung, cá tính', 'thumbnail' => 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=600', 'position' => 5, 'status' => 'active'],
        ['_id' => 'cat_office', 'title' => 'PHONG CÁCH', 'slug' => 'cong-so', 'description' => 'Lịch lãm, hiện đại', 'thumbnail' => 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=600', 'position' => 6, 'status' => 'active'],
        ['_id' => 'cat_sleepwear', 'title' => 'Đồ Ngủ & Mặc Nhà', 'slug' => 'do-ngu', 'description' => 'Thoải mái & Nhẹ nhàng', 'thumbnail' => 'https://images.unsplash.com/photo-1562157873-818bc0726f68?w=600', 'position' => 7, 'status' => 'active'],
        ['_id' => 'cat_unisex', 'title' => 'Đồ Unisex', 'slug' => 'unisex', 'description' => 'Thời trang phi giới tính', 'thumbnail' => 'https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?w=600', 'position' => 8, 'status' => 'active'],
        ['_id' => 'cat_winter', 'title' => 'Trang Phục Mùa Đông', 'slug' => 'mua-dong', 'description' => 'Ấm áp & Thời thượng', 'thumbnail' => 'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=600', 'position' => 9, 'status' => 'active'],
        ['_id' => 'cat_kids', 'title' => 'Đồ Trẻ Em', 'slug' => 'tre-em', 'description' => 'Đáng yêu & An toàn', 'thumbnail' => 'https://images.unsplash.com/photo-1519457431-44ccd64a579b?w=600', 'position' => 10, 'status' => 'active']
    ];

    $stmtCat = $conn->prepare("INSERT INTO product_categories (_id, title, slug, description, thumbnail, position, status, deleted) VALUES (:id, :title, :slug, :description, :thumbnail, :position, :status, 0)");
    foreach ($categories as $cat) {
        $stmtCat->execute([
            ':id' => $cat['_id'],
            ':title' => $cat['title'],
            ':slug' => $cat['slug'],
            ':description' => $cat['description'],
            ':thumbnail' => $cat['thumbnail'],
            ':position' => $cat['position'],
            ':status' => $cat['status']
        ]);
    }
    echo "- Đã nạp " . count($categories) . " Danh mục sản phẩm thành công.\n";

    // 1b. Chọn ngẫu nhiên 5 danh mục để gán lên thanh điều hướng (Navbar) để kiểm thử
    $randomKeys = array_rand($categories, 5);
    $randomCats = [];
    foreach ($randomKeys as $key) {
        $randomCats[] = $categories[$key];
    }
    $navPosition = 1;

    $stmtNav = $conn->prepare("INSERT INTO navbars (_id, title, link, position, status, deleted) VALUES (:id, :title, :link, :position, :status, 0)");
    foreach ($randomCats as $cat) {
        $stmtNav->execute([
            ':id' => 'nav_' . bin2hex(random_bytes(6)),
            ':title' => str_replace('Thời trang ', '', $cat['title']), // Rút gọn tiêu đề
            ':link' => 'products?category=' . $cat['slug'],
            ':position' => $navPosition++,
            ':status' => 'active'
        ]);
    }
    echo "- Đã nạp ngẫu nhiên 5 Menu thanh điều hướng (Navbar) kiểm thử thành công.\n";

    // 2. Thêm sản phẩm mẫu (Products)
    $products = [
        [
            '_id' => 'prod_polo',
            'title' => 'Áo Polo Basic GearX',
            'product_category_id' => 'cat_nam',
            'description' => 'Áo Polo chất liệu Cotton cá sấu thoáng mát, co giãn tốt, phù hợp đi làm và đi chơi.',
            'price' => 299000,
            'price_sale' => 249000,
            'thumbnail' => 'https://images.unsplash.com/photo-1581655353564-df123a1eb820?w=500',
            'status' => 'active',
            'featured' => 'yes'
        ],
        [
            '_id' => 'prod_bomber',
            'title' => 'Áo Khoác Bomber Kaki',
            'product_category_id' => 'cat_nam',
            'description' => 'Áo khoác Bomber chất kaki dày dặn phối khóa kéo kim loại sang trọng.',
            'price' => 450000,
            'price_sale' => 379000,
            'thumbnail' => 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=500',
            'status' => 'active',
            'featured' => 'yes'
        ],
        [
            '_id' => 'prod_somi_trang',
            'title' => 'Áo Sơ Mi Trắng Tay Dài Premium',
            'product_category_id' => 'cat_nam',
            'description' => 'Áo sơ mi trắng chất liệu cotton lụa cao cấp, chống nhăn, phom dáng ôm vừa vặn lịch lãm.',
            'price' => 350000,
            'price_sale' => null,
            'thumbnail' => 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=500',
            'status' => 'active',
            'featured' => 'yes'
        ],
        [
            '_id' => 'prod_somi_lua',
            'title' => 'Áo Sơ Mi Lụa Cổ Vest',
            'product_category_id' => 'cat_nam',
            'description' => 'Áo sơ mi lụa mềm mịn, cổ vest cá tính, mang lại cảm giác phóng khoáng, thời thượng.',
            'price' => 399000,
            'price_sale' => 320000,
            'thumbnail' => 'https://images.unsplash.com/photo-1603252109303-2751441dd157?w=500',
            'status' => 'active',
            'featured' => 'no'
        ],
        [
            '_id' => 'prod_jean_slim',
            'title' => 'Quần Jeans Slimfit Co Giãn',
            'product_category_id' => 'cat_nam',
            'description' => 'Quần jeans phom dáng slimfit trẻ trung, chất denim co giãn thoải mái khi vận động.',
            'price' => 499000,
            'price_sale' => null,
            'thumbnail' => 'https://images.unsplash.com/photo-1542272604-787c3835535d?w=500',
            'status' => 'active',
            'featured' => 'yes'
        ],
        [
            '_id' => 'prod_kaki_suong',
            'title' => 'Quần Kaki Ống Suông Hàn Quốc',
            'product_category_id' => 'cat_nam',
            'description' => 'Quần kaki ống suông phom dáng Hàn Quốc cực kỳ trendy, vải kaki dày dặn giữ phom tốt.',
            'price' => 420000,
            'price_sale' => 350000,
            'thumbnail' => 'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=500',
            'status' => 'active',
            'featured' => 'no'
        ],
        [
            '_id' => 'prod_short_kaki',
            'title' => 'Quần Short Kaki Basic',
            'product_category_id' => 'cat_nam',
            'description' => 'Quần short kaki năng động, độ dài ngang gối thích hợp đi chơi, dã ngoại mùa hè.',
            'price' => 220000,
            'price_sale' => null,
            'thumbnail' => 'https://images.unsplash.com/photo-1591195853828-11db59a44f6b?w=500',
            'status' => 'active',
            'featured' => 'yes'
        ],
        [
            '_id' => 'prod_thun_over',
            'title' => 'Áo Thun Oversize Streetwear',
            'product_category_id' => 'cat_nam',
            'description' => 'Áo thun phom rộng oversize cá tính, chất liệu 100% cotton co giãn 4 chiều cực mát.',
            'price' => 250000,
            'price_sale' => 199000,
            'thumbnail' => 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=500',
            'status' => 'active',
            'featured' => 'no'
        ],
        [
            '_id' => 'prod_khoac_gio',
            'title' => 'Áo Khoác Gió Chống Nước',
            'product_category_id' => 'cat_nam',
            'description' => 'Áo khoác gió 2 lớp chống thấm nước hiệu quả, cản gió tốt, có mũ trùm tiện lợi.',
            'price' => 550000,
            'price_sale' => null,
            'thumbnail' => 'https://images.unsplash.com/photo-1548883354-7622d03aca27?w=500',
            'status' => 'active',
            'featured' => 'no'
        ],
        [
            '_id' => 'prod_polo_sport',
            'title' => 'Áo Thun Polo Thể Thao Active',
            'product_category_id' => 'cat_nam',
            'description' => 'Áo thun polo thể thao chất liệu thun lạnh co giãn, thấm hút mồ hôi cực tốt.',
            'price' => 270000,
            'price_sale' => null,
            'thumbnail' => 'https://images.unsplash.com/photo-1581655353564-df123a1eb820?w=500',
            'status' => 'active',
            'featured' => 'no'
        ],
        [
            '_id' => 'prod_thun_unisex',
            'title' => 'Áo Thun Tay Lỡ Unisex Basic',
            'product_category_id' => 'cat_nam',
            'description' => 'Áo thun tay lỡ chất liệu cotton dày dặn, phom rộng rãi phù hợp cả nam và nữ.',
            'price' => 199000,
            'price_sale' => 159000,
            'thumbnail' => 'https://images.unsplash.com/photo-1562157873-818bc0726f68?w=500',
            'status' => 'active',
            'featured' => 'yes'
        ],
        [
            '_id' => 'prod_somi_hawaii',
            'title' => 'Áo Sơ Mi Họa Tiết Hawaii',
            'product_category_id' => 'cat_nam',
            'description' => 'Áo sơ mi ngắn tay họa tiết nhiệt đới rực rỡ, chất vải nhẹ mát phù hợp đi du lịch, đi biển.',
            'price' => 380000,
            'price_sale' => null,
            'thumbnail' => 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=500',
            'status' => 'active',
            'featured' => 'no'
        ],
        [
            '_id' => 'prod_somi_oxford',
            'title' => 'Áo Sơ Mi Oxford Cổ Điển',
            'product_category_id' => 'cat_nam',
            'description' => 'Áo sơ mi chất vải Oxford dệt nổi đặc trưng, đứng phom, phong cách thanh lịch Châu Âu.',
            'price' => 410000,
            'price_sale' => null,
            'thumbnail' => 'https://images.unsplash.com/photo-1603252109303-2751441dd157?w=500',
            'status' => 'active',
            'featured' => 'no'
        ],
        [
            '_id' => 'prod_denim_vintage',
            'title' => 'Áo Khoác Denim Vintage Heavyweight',
            'product_category_id' => 'cat_nam',
            'description' => 'Áo khoác bò chất denim dày dặn, mài bạc phong cách vintage bụi bặm.',
            'price' => 690000,
            'price_sale' => 590000,
            'thumbnail' => 'https://images.unsplash.com/photo-1576995853123-5a10305d93c0?w=500',
            'status' => 'active',
            'featured' => 'yes'
        ],
        [
            '_id' => 'prod_cardigan_len',
            'title' => 'Áo Khoác Cardigan Len Mỏng',
            'product_category_id' => 'cat_nam',
            'description' => 'Áo khoác len cardigan dệt kim mỏng nhẹ, cổ V sang trọng cho mùa thu đông se lạnh.',
            'price' => 480000,
            'price_sale' => null,
            'thumbnail' => 'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?w=500',
            'status' => 'active',
            'featured' => 'no'
        ],
        [
            '_id' => 'prod_jogger_thun',
            'title' => 'Quần Jogger Thun Thể Thao',
            'product_category_id' => 'cat_nam',
            'description' => 'Quần jogger thun cotton da cá dày dặn, bo gấu năng động, co giãn 4 chiều.',
            'price' => 310000,
            'price_sale' => 250000,
            'thumbnail' => 'https://images.unsplash.com/photo-1552346154-21d32810aba3?w=500',
            'status' => 'active',
            'featured' => 'no'
        ],
        [
            '_id' => 'prod_quan_au',
            'title' => 'Quần Âu Nam Lịch Lãm Phom Slim',
            'product_category_id' => 'cat_nam',
            'description' => 'Quần tây chất vải tuyết mưa đứng dáng, chống nhăn, thích hợp mặc công sở.',
            'price' => 450000,
            'price_sale' => null,
            'thumbnail' => 'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=500',
            'status' => 'active',
            'featured' => 'yes'
        ],
        [
            '_id' => 'prod_short_jean',
            'title' => 'Quần Short Jeans Rách Cá Tính',
            'product_category_id' => 'cat_nam',
            'description' => 'Quần short bò denim mài xước rách gối phong cách bụi bặm đường phố.',
            'price' => 280000,
            'price_sale' => 220000,
            'thumbnail' => 'https://images.unsplash.com/photo-1591195853828-11db59a44f6b?w=500',
            'status' => 'active',
            'featured' => 'no'
        ]
    ];

    $stmtProd = $conn->prepare("INSERT INTO products (_id, title, product_category_id, description, price, price_sale, thumbnail, status, featured, deleted) 
                               VALUES (:id, :title, :category_id, :description, :price, :price_sale, :thumbnail, :status, :featured, 0)");
    $catIds = array_column($categories, '_id');
    foreach ($products as $p) {
        $randomCatId = $catIds[array_rand($catIds)]; // Gán danh mục ngẫu nhiên từ 10 danh mục
        $stmtProd->execute([
            ':id' => $p['_id'],
            ':title' => $p['title'],
            ':category_id' => $randomCatId,
            ':description' => $p['description'],
            ':price' => $p['price'],
            ':price_sale' => $p['price_sale'],
            ':thumbnail' => $p['thumbnail'],
            ':status' => $p['status'],
            ':featured' => $p['featured']
        ]);
    }
    echo "- Đã nạp " . count($products) . " Sản phẩm mẫu thành công với danh mục ngẫu nhiên.\n";

    // 3. Thêm biến thể sản phẩm (Product Variants)
    $variants = [];
    foreach ($products as $p) {
        // Tạo tự động biến thể cho từng sản phẩm để tránh dài dòng thủ công
        $sizes = ['S', 'M', 'L', 'XL'];
        $colors = ['black', 'white', 'gray', 'blue', 'beige', 'green'];
        
        // Chọn ngẫu nhiên 2 màu và 3 size cho mỗi sản phẩm để tạo 6 biến thể
        $randColors = array_intersect_key($colors, array_flip(array_rand($colors, 2)));
        $randSizes = array_intersect_key($sizes, array_flip(array_rand($sizes, 3)));
        
        foreach ($randColors as $color) {
            foreach ($randSizes as $size) {
                $vId = 'var_' . substr($p['_id'], 5) . '_' . substr($color, 0, 3) . '_' . strtolower($size);
                $variants[] = [
                    '_id' => $vId,
                    'product_id' => $p['_id'],
                    'color' => $color,
                    'size' => $size,
                    'stock' => rand(10, 100),
                    'sku' => strtoupper(substr($p['_id'], 5)) . '-' . strtoupper(substr($color, 0, 3)) . '-' . $size
                ];
            }
        }
    }

    $stmtVar = $conn->prepare("INSERT INTO product_variants (_id, product_id, color, size, stock, sku) VALUES (:id, :product_id, :color, :size, :stock, :sku)");
    foreach ($variants as $v) {
        $stmtVar->execute([
            ':id' => $v['_id'],
            ':product_id' => $v['product_id'],
            ':color' => $v['color'],
            ':size' => $v['size'],
            ':stock' => $v['stock'],
            ':sku' => $v['sku']
        ]);
    }
    echo "- Đã nạp " . count($variants) . " Biến thể sản phẩm tự động thành công.\n";

    // Seed sample inventory transaction logs for Nhật Ký Biến Động Kho Hàng
    $stmtTrans = $conn->prepare("INSERT INTO inventory_transactions (_id, variant_id, sku, change_qty, type, reason, created_by, created_at) VALUES (:id, :variant_id, :sku, :change_qty, :type, :reason, :created_by, NOW())");
    // Create a few sample transactions per first 5 variants
    $sampleCount = 0;
    foreach ($variants as $v) {
        if ($sampleCount >= 5) break;
        $transId = 'trans_' . bin2hex(random_bytes(6));
        $type = $sampleCount % 2 == 0 ? 'import' : 'export';
        $change = $type === 'import' ? rand(5, 20) : -rand(1, 10);
        $reason = $type === 'import' ? 'Nhập kho mẫu' : 'Xuất kho mẫu';
        $stmtTrans->execute([
            ':id' => $transId,
            ':variant_id' => $v['_id'],
            ':sku' => $v['sku'],
            ':change_qty' => $change,
            ':type' => $type,
            ':reason' => $reason,
            ':created_by' => 'seed_script'
        ]);
        $sampleCount++;
    }

    // 4. Thêm tài khoản khách hàng mẫu (Users)
    $users = [
        [
            '_id' => 'user_client_1',
            'fullname' => 'Nguyễn Văn A',
            'email' => 'client1@gmail.com',
            'password' => '123456',
            'address' => '123 Đường Lê Lợi, Quận 1, TP. HCM',
            'phone' => '0987654321',
            'is_verified' => 1
        ],
        [
            '_id' => 'user_client_2',
            'fullname' => 'Trần Thị B',
            'email' => 'client2@gmail.com',
            'password' => '123456',
            'address' => '456 Đường Nguyễn Huệ, Quận 3, TP. HCM',
            'phone' => '0901234567',
            'is_verified' => 0 // Chưa xác minh để test hiển thị badge
        ]
    ];

    $stmtUser = $conn->prepare("INSERT INTO users (_id, fullname, email, password, address, phone, is_verified, deleted) 
                               VALUES (:id, :fullname, :email, :password, :address, :phone, :is_verified, 0)");
    foreach ($users as $u) {
        $hashedPassword = password_hash($u['password'], PASSWORD_BCRYPT);
        $stmtUser->execute([
            ':id' => $u['_id'],
            ':fullname' => $u['fullname'],
            ':email' => $u['email'],
            ':password' => $hashedPassword,
            ':address' => $u['address'],
            ':phone' => $u['phone'],
            ':is_verified' => $u['is_verified']
        ]);
    }
    echo "- Đã nạp 2 Khách hàng thành công.\n";

    // 5. Thêm đơn hàng mẫu (Orders)
    $orders = [
        [
            '_id' => 'ORD-2026-9871',
            'user_id' => 'user_client_1',
            'total_price' => 749000,
            'payment_method' => 'cod',
            'shipping_address' => '123 Đường Lê Lợi, Quận 1, TP. HCM',
            'phone' => '0987654321',
            'note' => 'Giao giờ hành chính giúp em.',
            'status' => 'pending'
        ],
        [
            '_id' => 'ORD-2026-9872',
            'user_id' => 'user_client_2',
            'total_price' => 120000,
            'payment_method' => 'momo',
            'shipping_address' => '456 Đường Nguyễn Huệ, Quận 3, TP. HCM',
            'phone' => '0901234567',
            'note' => '',
            'status' => 'delivered'
        ]
    ];

    $stmtOrder = $conn->prepare("INSERT INTO orders (_id, user_id, total_price, payment_method, shipping_address, phone, note, status) 
                                 VALUES (:id, :user_id, :total_price, :payment_method, :shipping_address, :phone, :note, :status)");
    foreach ($orders as $o) {
        $stmtOrder->execute([
            ':id' => $o['_id'],
            ':user_id' => $o['user_id'],
            ':total_price' => $o['total_price'],
            ':payment_method' => $o['payment_method'],
            ':shipping_address' => $o['shipping_address'],
            ':phone' => $o['phone'],
            ':note' => $o['note'],
            ':status' => $o['status']
        ]);
    }
    echo "- Đã nạp 2 Đơn hàng thành công.\n";

    echo "\n=== Nạp dữ liệu kiểm thử hoàn tất thành công! ===\n";

} catch (Exception $e) {
    echo "Lỗi khi nạp dữ liệu: " . $e->getMessage() . "\n";
}
