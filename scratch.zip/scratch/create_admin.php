<?php
require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../core/helpers.php';
loadEnv(__DIR__ . '/../.env');
require_once __DIR__ . '/../config/database.php'; // kết nối $conn

try {
    // 1. Tạo bảng accounts nếu chưa có
    $conn->exec("CREATE TABLE IF NOT EXISTS `accounts` (
        `_id` VARCHAR(50) PRIMARY KEY,
        `fullname` VARCHAR(255) NOT NULL,
        `email` VARCHAR(255) NOT NULL UNIQUE,
        `password` VARCHAR(255) NOT NULL,
        `status` VARCHAR(50) DEFAULT 'active',
        `role_slug` VARCHAR(50) DEFAULT 'admin',
        `deleted` TINYINT(1) DEFAULT 0,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    // 2. Thông tin Admin cần tạo
    $email = 'admin@fashion.com';
    $password = '123456'; // Mật khẩu đăng nhập
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
    
    // Kiểm tra trùng lặp email trước khi thêm
    $checkStmt = $conn->prepare("SELECT COUNT(*) FROM accounts WHERE email = :email AND deleted = FALSE");
    $checkStmt->execute([':email' => $email]);
    if ($checkStmt->fetchColumn() > 0) {
        echo "Tài khoản Admin với email '{$email}' đã tồn tại trong hệ thống!\n";
        exit;
    }
    
    $stmt = $conn->prepare("INSERT INTO accounts (_id, fullname, email, password, role_slug) 
                            VALUES (:id, :fullname, :email, :password, :role)");
    $stmt->execute([
        ':id' => 'ac_' . bin2hex(random_bytes(6)),
        ':fullname' => 'Administrator',
        ':email' => $email,
        ':password' => $hashedPassword,
        ':role' => 'admin'
    ]);

    echo "Tạo tài khoản Admin thành công!\n";
    echo "Email: $email\nMật khẩu: $password\n";

} catch (Exception $e) {
    echo "Lỗi: " . $e->getMessage() . "\n";
}
