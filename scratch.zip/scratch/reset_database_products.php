<?php
// Script khôi phục và thiết lập lại cơ sở dữ liệu sản phẩm, biến thể và nhật ký kho mẫu
// Chạy bằng trình duyệt: http://localhost/.../scratch/reset_database_products.php
// Hoặc chạy bằng CLI: C:\xampp\php\php.exe scratch\reset_database_products.php

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../core/helpers.php';
loadEnv(__DIR__ . '/../.env');
require_once __DIR__ . '/../config/database.php'; // Trả về biến kết nối PDO là $conn hoặc tương tự

// Đảm bảo kết nối CSDL hợp lệ
if (!isset($conn)) {
    // Nếu không tự động nạp, thử kết nối thủ công từ biến môi trường
    $host = $_ENV['DB_HOST'] ?? '127.0.0.1';
    $dbName = $_ENV['DB_DATABASE'] ?? 'web_db';
    $username = $_ENV['DB_USERNAME'] ?? 'root';
    $password = $_ENV['DB_PASSWORD'] ?? '';
    try {
        $conn = new PDO("mysql:host=$host;dbname=$dbName;charset=utf8mb4", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        die("Kết nối CSDL thất bại: " . $e->getMessage());
    }
}

echo "=== BẮT ĐẦU RESET CƠ SỞ DỮ LIỆU SẢN PHẨM ===<br>\n";

try {
    // 1. Xóa sạch dữ liệu cũ
    $conn->exec("SET FOREIGN_KEY_CHECKS = 0;");
    $conn->exec("TRUNCATE TABLE `product_variants`;");
    $conn->exec("TRUNCATE TABLE `products`;");
    $conn->exec("TRUNCATE TABLE `product_images`;");
    $conn->exec("TRUNCATE TABLE `product_categories`;");
    
    // Nếu bảng nhật ký tồn tại thì xóa sạch
    $conn->exec("DROP TABLE IF EXISTS `inventory_transactions`;");
    $conn->exec("CREATE TABLE `inventory_transactions` (
        `_id` VARCHAR(50) NOT NULL PRIMARY KEY,
        `variant_id` VARCHAR(50) NOT NULL,
        `sku` VARCHAR(100) NOT NULL,
        `change_qty` INT NOT NULL,
        `type` VARCHAR(50) NOT NULL,
        `reason` TEXT NULL,
        `created_by` VARCHAR(100) NOT NULL,
        `createdAt` DATETIME NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
    
    $conn->exec("SET FOREIGN_KEY_CHECKS = 1;");
    echo "1. Đã xóa sạch dữ liệu cũ thành công.<br>\n";

    // 2. Thêm Danh mục mẫu
    $categories = [
        ['cat_1', 'Áo Khoác Nam'],
        ['cat_2', 'Quần Jeans'],
        ['cat_3', 'Áo Thun Basic']
    ];
    $stmtCat = $conn->prepare("INSERT INTO `product_categories` (`_id`, `title`) VALUES (?, ?)");
    foreach ($categories as $cat) {
        $stmtCat->execute($cat);
    }
    echo "2. Đã thêm 3 Danh mục sản phẩm mẫu.<br>\n";

    // 3. Thêm Sản phẩm mẫu
    $products = [
        ['prod_1', 'cat_1', 'Áo Khoác Bomber Premium', 'Áo khoác bomber thiết kế tối giản, chất liệu gió trượt nước.', 450000.00],
        ['prod_2', 'cat_2', 'Quần Jeans Slimfit Vintage', 'Quần jeans chất bò thô co giãn nhẹ dáng trẻ trung.', 380000.00],
        ['prod_3', 'cat_3', 'Áo Thun Cotton Organic', 'Áo thun cotton 100% thoáng mát hút mồ hôi cực tốt.', 190000.00]
    ];
    $stmtProd = $conn->prepare("INSERT INTO `products` (`_id`, `product_category_id`, `title`, `description`, `price`) VALUES (?, ?, ?, ?, ?)");
    foreach ($products as $prod) {
        $stmtProd->execute($prod);
    }
    echo "3. Đã thêm 3 Sản phẩm gốc mẫu.<br>\n";

    // 4. Thêm Biến thể mẫu (Sử dụng SKU cụ thể để test)
    $variants = [
        // Áo Khoác (prod_1)
        ['var_1', 'prod_1', 'BOMBER-BLU-S', 50, 'Xanh', 'S'],
        ['var_2', 'prod_1', 'BOMBER-BLU-M', 75, 'Xanh', 'M'],
        ['var_3', 'prod_1', 'BOMBER-BLU-L', 100, 'Xanh', 'L'],
        ['var_4', 'prod_1', 'BOMBER-BLK-S', 40, 'Đen', 'S'],
        ['var_5', 'prod_1', 'BOMBER-BLK-M', 60, 'Đen', 'M'],
        
        // Quần Jeans (prod_2)
        ['var_6', 'prod_2', 'JEAN-BLU-29', 30, 'Xanh nhạt', '29'],
        ['var_7', 'prod_2', 'JEAN-BLU-30', 45, 'Xanh nhạt', '30'],
        ['var_8', 'prod_2', 'JEAN-BLU-31', 50, 'Xanh nhạt', '31'],
        ['var_9', 'prod_2', 'JEAN-BLK-29', 25, 'Đen', '29'],
        ['var_10', 'prod_2', 'JEAN-BLK-30', 40, 'Đen', '30'],
        
        // Áo Thun (prod_3)
        ['var_11', 'prod_3', 'TSHIRT-WHT-S', 120, 'Trắng', 'S'],
        ['var_12', 'prod_3', 'TSHIRT-WHT-M', 150, 'Trắng', 'M'],
        ['var_13', 'prod_3', 'TSHIRT-WHT-L', 130, 'Trắng', 'L'],
        ['var_14', 'prod_3', 'TSHIRT-BLK-M', 90, 'Đen', 'M'],
        ['var_15', 'prod_3', 'TSHIRT-BLK-L', 110, 'Đen', 'L']
    ];

    $stmtVar = $conn->prepare("INSERT INTO `product_variants` (`_id`, `product_id`, `sku`, `stock`, `color`, `size`) VALUES (?, ?, ?, ?, ?, ?)");
    foreach ($variants as $var) {
        $stmtVar->execute($var);
    }
    echo "4. Đã thêm 15 Biến thể sản phẩm với đầy đủ mã SKU.<br>\n";

    echo "<br><span style='color: green; font-weight: bold;'>=== KHÔI PHỤC CSDL THÀNH CÔNG! ===</span>";
} catch (PDOException $e) {
    echo "<br><span style='color: red; font-weight: bold;'>LỖI: " . $e->getMessage() . "</span>";
}
