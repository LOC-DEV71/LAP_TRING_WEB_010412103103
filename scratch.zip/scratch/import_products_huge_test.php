<?php
// Script nhập khẩu 150 sản phẩm & biến thể từ file products_huge.csv vào CSDL
// Chạy bằng trình duyệt: http://localhost/.../scratch/import_products_huge.php
// Hoặc chạy bằng CLI: C:\xampp\php\php.exe scratch\import_products_huge.php

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../core/helpers.php';
loadEnv(__DIR__ . '/../.env');
require_once __DIR__ . '/../config/database.php';

if (!isset($conn)) {
    $host = $_ENV['DB_HOST'] ?? '127.0.0.1';
    $dbName = $_ENV['DB_DATABASE'] ?? 'web_db';
    $username = $_ENV['DB_USERNAME'] ?? 'root';
    $password = $_ENV['DB_PASSWORD'] ?? '';
    try {
        $conn = new PDO("mysql:host=$host;dbname=$dbName;charset=utf8mb4", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        die("Kết nối CSDL thất bại: " . $e->getMessage());
    }
}

echo "=== BẮT ĐẦU NHẬP SẢN PHẨM DUNG LƯỢNG LỚN ===<br>\n";

$csvPath = __DIR__ . '/products_huge_test.csv';
if (!file_exists($csvPath)) {
    die("Lỗi: Không tìm thấy tệp products_huge_test.csv. Vui lòng chạy generate_huge_data.php trước!");
}

$handle = fopen($csvPath, 'r');
// Bỏ qua tiêu đề
fgetcsv($handle);

$conn->beginTransaction();
try {
    $categoryCache = [];
    $productCache = [];
    
    $successCount = 0;

    while (($row = fgetcsv($handle)) !== false) {
        $catName = trim($row[0] ?? '');
        $prodTitle = trim($row[1] ?? '');
        $price = (float)($row[2] ?? 0);
        $desc = trim($row[3] ?? '');
        $sku = trim($row[4] ?? '');
        $color = trim($row[5] ?? '');
        $size = trim($row[6] ?? '');

        if (empty($sku) || empty($prodTitle)) {
            continue;
        }

        // 1. Xử lý Danh mục
        if (!isset($categoryCache[$catName])) {
            // Tìm trong DB xem đã có danh mục tên này chưa
            $stmt = $conn->prepare("SELECT _id FROM product_categories WHERE title = ?");
            $stmt->execute([$catName]);
            $catId = $stmt->fetchColumn();

            if (!$catId) {
                $catId = 'cat_' . bin2hex(random_bytes(6));
                $insertCat = $conn->prepare("INSERT INTO product_categories (_id, title) VALUES (?, ?)");
                $insertCat->execute([$catId, $catName]);
            }
            $categoryCache[$catName] = $catId;
        }
        $catId = $categoryCache[$catName];

        // 2. Xử lý Sản phẩm gốc
        if (!isset($productCache[$prodTitle])) {
            $stmt = $conn->prepare("SELECT _id FROM products WHERE title = ?");
            $stmt->execute([$prodTitle]);
            $prodId = $stmt->fetchColumn();

            if (!$prodId) {
                $prodId = 'prod_' . bin2hex(random_bytes(6));
                $insertProd = $conn->prepare("INSERT INTO products (_id, product_category_id, title, description, price) VALUES (?, ?, ?, ?, ?)");
                $insertProd->execute([$prodId, $catId, $prodTitle, $desc, $price]);
            }
            $productCache[$prodTitle] = $prodId;
        }
        $prodId = $productCache[$prodTitle];

        // 3. Xử lý Biến thể (Product Variant)
        // Kiểm tra xem SKU này đã tồn tại chưa
        $stmt = $conn->prepare("SELECT _id FROM product_variants WHERE sku = ?");
        $stmt->execute([$sku]);
        $varId = $stmt->fetchColumn();

        if (!$varId) {
            $varId = 'var_' . bin2hex(random_bytes(6));
            $insertVar = $conn->prepare("INSERT INTO product_variants (_id, product_id, sku, stock, color, size) VALUES (?, ?, ?, 0, ?, ?)");
            $insertVar->execute([$varId, $prodId, $sku, $color, $size]);
            $successCount++;
        }
    }

    $conn->commit();
    echo "<br><span style='color: green; font-weight: bold;'>ĐÃ NHẬP THÀNH CÔNG $successCount BIẾN THỂ SẢN PHẨM MỚI VÀO CSDL!</span><br>\n";
    echo "Các sản phẩm mới đều có số lượng tồn kho ban đầu là 0. Bạn có thể dùng tệp <strong>inventory_huge_test.csv</strong> để import cập nhật tồn kho.";
} catch (Exception $e) {
    $conn->rollBack();
    echo "<br><span style='color: red; font-weight: bold;'>LỖI NHẬP SẢN PHẨM: " . $e->getMessage() . "</span>";
}

fclose($handle);
?>
