<?php
require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../core/helpers.php';
loadEnv(__DIR__ . '/../.env');
require_once __DIR__ . '/../config/database.php'; // Kết nối PDO qua biến $conn

try {
    echo "Bắt đầu reset tài khoản người dùng về trạng thái mặc định (chưa xác thực, chưa có ảnh đại diện)...\n";

    // 1. Cập nhật bảng users
    // Đặt lại is_verified = 0, avatar = NULL, và khôi phục thông tin cá nhân gốc của các tài khoản test
    $sql = "UPDATE users SET 
                is_verified = 0, 
                avatar = NULL, 
                verification_token = NULL,
                reset_token = NULL,
                reset_token_expires = NULL,
                fullname = CASE 
                    WHEN _id = 'user_client_1' THEN 'Nguyễn Văn A'
                    WHEN _id = 'user_client_2' THEN 'Trần Thị B'
                    ELSE fullname 
                END,
                phone = CASE 
                    WHEN _id = 'user_client_1' THEN '0987654321'
                    WHEN _id = 'user_client_2' THEN '0901234567'
                    ELSE phone 
                END,
                address = CASE 
                    WHEN _id = 'user_client_1' THEN '123 Đường Lê Lợi, Quận 1, TP. HCM'
                    WHEN _id = 'user_client_2' THEN '456 Đường Nguyễn Huệ, Quận 3, TP. HCM'
                    ELSE address 
                END
            WHERE deleted = FALSE";
            
    $affected = $conn->exec($sql);
    
    // 2. Xóa các tệp tin ảnh đại diện đã upload trong thư mục public/uploads/avatars/
    $avatarDir = __DIR__ . '/../public/uploads/avatars/';
    if (is_dir($avatarDir)) {
        $files = glob($avatarDir . '*');
        foreach ($files as $file) {
            if (is_file($file)) {
                @unlink($file);
            }
        }
        echo "- Đã dọn dẹp thư mục ảnh đại diện đã tải lên.\n";
    }

    echo "- Đã reset thành công $affected tài khoản người dùng về trạng thái trắng.\n";
    echo "=== Đã hoàn tất reset tài khoản! ===\n";

} catch (Exception $e) {
    echo "Lỗi khi reset tài khoản: " . $e->getMessage() . "\n";
}
