<?php
/**
 * Table recreation script cho LAP_TRING_WEB.
 * Đã được chuẩn hóa theo seed_fake_data.php
 */

require_once __DIR__ . '/../config/database.php';

try {
    $conn->exec("SET FOREIGN_KEY_CHECKS=0;");

    $dropQueries = [
        "DROP TABLE IF EXISTS cart_items;",
        "DROP TABLE IF EXISTS carts;",
        "DROP TABLE IF EXISTS likes;",
        "DROP TABLE IF EXISTS order_items;",
        "DROP TABLE IF EXISTS orders;",
        "DROP TABLE IF EXISTS users;",
        "DROP TABLE IF EXISTS inventory_transactions;",
        "DROP TABLE IF EXISTS product_images;",
        "DROP TABLE IF EXISTS product_variants;",
        "DROP TABLE IF EXISTS products;",
        "DROP TABLE IF EXISTS settings;",
        "DROP TABLE IF EXISTS navbars;",
        "DROP TABLE IF EXISTS product_categories;"
    ];

    foreach ($dropQueries as $sql) {
        $conn->exec($sql);
        echo "🗑️ Dropped if existed: " . trim($sql, ';') . "\n";
    }

    $createQueries = [
        "CREATE TABLE IF NOT EXISTS product_categories (
            _id VARCHAR(50) PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            slug VARCHAR(255) NOT NULL,
            description VARCHAR(255),
            thumbnail VARCHAR(255),
            position INT DEFAULT 0,
            status VARCHAR(50) DEFAULT 'active',
            deleted TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
        
        "CREATE TABLE IF NOT EXISTS navbars (
            _id VARCHAR(50) PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            link VARCHAR(255) NOT NULL,
            position INT DEFAULT 0,
            status VARCHAR(50) DEFAULT 'active',
            deleted TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
        
        "CREATE TABLE IF NOT EXISTS settings (
            `key` VARCHAR(50) PRIMARY KEY,
            `value` TEXT,
            `description` VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
        
        "CREATE TABLE IF NOT EXISTS products (
            _id VARCHAR(50) PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            product_category_id VARCHAR(50) NOT NULL,
            description TEXT,
            price INT NOT NULL,
            price_sale INT NULL,
            thumbnail VARCHAR(255),
            status VARCHAR(50) DEFAULT 'active',
            featured VARCHAR(10) DEFAULT 'no',
            deleted TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (product_category_id) REFERENCES product_categories(_id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
        
        "CREATE TABLE IF NOT EXISTS product_variants (
            _id VARCHAR(50) PRIMARY KEY,
            product_id VARCHAR(50) NOT NULL,
            color VARCHAR(50) NOT NULL,
            size VARCHAR(10) NOT NULL,
            stock INT DEFAULT 0,
            sku VARCHAR(100) UNIQUE,
            deleted TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (product_id) REFERENCES products(_id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
        
        "CREATE TABLE IF NOT EXISTS product_images (
            _id VARCHAR(50) PRIMARY KEY,
            product_id VARCHAR(50) NOT NULL,
            image_url VARCHAR(255) NOT NULL,
            position INT DEFAULT 0,
            deleted TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (product_id) REFERENCES products(_id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
        
        "CREATE TABLE IF NOT EXISTS inventory_transactions (
            _id VARCHAR(50) NOT NULL PRIMARY KEY,
            variant_id VARCHAR(50) NOT NULL,
            sku VARCHAR(100) NOT NULL,
            change_qty INT NOT NULL,
            type VARCHAR(50) NOT NULL,
            reason TEXT NULL,
            created_by VARCHAR(100) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (variant_id) REFERENCES product_variants(_id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
        
        "CREATE TABLE IF NOT EXISTS users (
            _id VARCHAR(50) PRIMARY KEY,
            fullname VARCHAR(255) NOT NULL,
            email VARCHAR(255) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            address TEXT,
            phone VARCHAR(20),
            is_verified TINYINT(1) DEFAULT 0,
            verification_token VARCHAR(255) NULL,
            deleted TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
        
        "CREATE TABLE IF NOT EXISTS orders (
            _id VARCHAR(50) PRIMARY KEY,
            user_id VARCHAR(50) NOT NULL,
            total_price INT NOT NULL,
            payment_method VARCHAR(20) NOT NULL,
            shipping_address TEXT NOT NULL,
            phone VARCHAR(20) NOT NULL,
            note TEXT,
            status VARCHAR(20) DEFAULT 'pending',
            deleted TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(_id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
        
        "CREATE TABLE IF NOT EXISTS order_items (
            _id VARCHAR(50) PRIMARY KEY,
            order_id VARCHAR(50) NOT NULL,
            variant_id VARCHAR(50) NOT NULL,
            quantity INT NOT NULL,
            price INT NOT NULL,
            deleted TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (order_id) REFERENCES orders(_id) ON DELETE CASCADE,
            FOREIGN KEY (variant_id) REFERENCES product_variants(_id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
        
        "CREATE TABLE IF NOT EXISTS likes (
            _id VARCHAR(50) PRIMARY KEY,
            user_id VARCHAR(50) NOT NULL,
            product_id VARCHAR(50) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(_id) ON DELETE CASCADE,
            FOREIGN KEY (product_id) REFERENCES products(_id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
        
        "CREATE TABLE IF NOT EXISTS carts (
            _id VARCHAR(50) PRIMARY KEY,
            user_id VARCHAR(50) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(_id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
        
        "CREATE TABLE IF NOT EXISTS cart_items (
            _id VARCHAR(50) PRIMARY KEY,
            cart_id VARCHAR(50) NOT NULL,
            variant_id VARCHAR(50) NOT NULL,
            quantity INT NOT NULL DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (cart_id) REFERENCES carts(_id) ON DELETE CASCADE,
            FOREIGN KEY (variant_id) REFERENCES product_variants(_id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;"
    ];

    foreach ($createQueries as $sql) {
        $conn->exec($sql);
        echo "✅ Created: " . preg_split('/\s+/', trim($sql))[2] . "\n";
    }

    $conn->exec("SET FOREIGN_KEY_CHECKS=1;");
    echo "\nAll tables have been dropped (if existed) and recreated successfully.\n";
} catch (PDOException $e) {
    echo "❌ Error during table recreation: " . $e->getMessage() . "\n";
}
?>