<?php
// Script tự động tạo tệp CSV kiểm thử dựa trên mã SKU thực tế trong CSDL
require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../core/helpers.php';
loadEnv(__DIR__ . '/../.env');
require_once __DIR__ . '/../config/database.php';

use Models\Product\ProductVariant;

$variantModel = new ProductVariant();
$db = $variantModel->getDbConnection();

// Lấy tối đa 5 mã SKU thực tế từ cơ sở dữ liệu
$sql = "SELECT sku FROM product_variants WHERE sku IS NOT NULL AND sku != '' LIMIT 5";
$stmt = $db->query($sql);
$skus = $stmt->fetchAll(PDO::FETCH_COLUMN);

// Nếu không có SKU nào, tạo một số SKU giả lập
if (empty($skus)) {
    $skus = ['SKU-MOCK-01', 'SKU-MOCK-02', 'SKU-MOCK-03'];
}

$csvPath = __DIR__ . '/inventory_import_fake.csv';
$file = fopen($csvPath, 'w');

// Ghi tiêu đề cột
fputcsv($file, ['sku', 'change_qty', 'type', 'reason']);

// Ghi các dòng dữ liệu mẫu khớp với SKU thực tế
$types = ['import', 'import', 'export', 'import', 'export'];
$reasons = [
    'Nhập kho lô hàng bổ sung đầu tuần',
    'Nhập kho hàng mẫu trưng bày',
    'Xuất kho trả hàng lỗi nhà cung cấp',
    'Điều chỉnh tăng sau khi kiểm kho thực tế',
    'Xuất hàng làm quà tặng sự kiện'
];

foreach ($skus as $index => $sku) {
    $qty = ($index % 2 === 0) ? 25 : -5;
    $type = $qty > 0 ? 'import' : 'export';
    $reason = $reasons[$index % count($reasons)];
    
    fputcsv($file, [$sku, $qty, $type, $reason]);
}

fclose($file);
echo "Đã nâng cấp thành công tệp CSV với " . count($skus) . " mã SKU thực tế từ cơ sở dữ liệu!\n";
foreach ($skus as $sku) {
    echo "- SKU: $sku\n";
}
?>
